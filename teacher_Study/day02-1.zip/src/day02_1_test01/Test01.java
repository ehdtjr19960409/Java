package test01;

public class Test01 { //클래스의 중괄호 시작영역
	public static void main(String[] args) { //main 메소드의 중괄호 시작영역
		System.out.println("김영선"); //김영선이라는 값을 콘솔창에 출력하고 줄바꿈한다
		System.out.println("java");
		System.out.println("2일차 수업");
		System.out.println("2024년 11월 24일");
	} //main 메소드의 중괄호 끝 영역
} // 클래스의 중괄호 끝 영역
