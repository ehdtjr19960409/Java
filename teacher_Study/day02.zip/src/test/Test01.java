package test;

public class Test01 {
	public static void main(String[] args) {
		System.out.println("김영선");
		System.out.println(2024 + 1); 
		//소괄호안에 있는 2024 + 1값의 덧셈 연산결과를 콘솔창에 출력하고 줄바꿈한다
	}
}
