package task;

public class Task03 {
	public static void main(String[] args) {
		//int, long, double, float, boolean, char
		//1. 정수(int) -> 모든 자료형 강제형변환 가능여부 확인
		
		//2. 정수(long) -> 모든 자료형 강제형변환 가능여부 확인
		
		//3. 실수(double) -> 모든 자료형 강제형변환 가능여부 확인
		
		//4. 실수(float) -> 모든 자료형 강제형변환 가능여부 확인
		
		//5. 논리형 (boolean) -> 모든 자료형 강제형변환 가능여부 확인
		
		//6. 문자형(char) -> 모든 자료형 강제형변환 가능여부 확인
		
	}
}
