package ex04_신동석;

public class Person {
	
	
	//필드생성 -> private이므로 getter setter 생각
	private String name;
	
	
	
	public void setName(String name) {
		this.name = name;
	}

	

	//메소드 생성
	void getName() {
		this.name = name;
		
	}
}
