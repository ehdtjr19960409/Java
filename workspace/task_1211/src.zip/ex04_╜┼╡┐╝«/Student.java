package ex04_신동석;

//Person 즉 부모를 상속받아야한다
public class Student extends Person{
	
	//필드 생성 
	private int javaScore;
	private int dbmsScore;
	private int htmlScore;
	
	//생성자 호출하고, 각점수 초기화

	
	
	//필드에서 private로 접근제한자를 선언했기 때문에 getter setter가 필요
	public int getJavaScore() {
		return javaScore;
	}

	public Student(int javaScore, int dbmsScore, int htmlScore) {
		super();
		this.javaScore = javaScore;
		this.dbmsScore = dbmsScore;
		this.htmlScore = htmlScore;
	}

	public void setJavaScore(int javaScore) {
		this.javaScore = javaScore;
	}

	public int getDbmsScore() {
		return dbmsScore;
	}

	public void setDbmsScore(int dbmsScore) {
		this.dbmsScore = dbmsScore;
	}

	public int getHtmlScore() {
		return htmlScore;
	}

	public void setHtmlScore(int htmlScore) {
		this.htmlScore = htmlScore;
	}


	//세 과목 점수를 더한 값을 반환
	int getTotalScore() {
		return javaScore + dbmsScore + htmlScore;
	}
	
	//평균(정수형)으로 반환
	int  getAverageScore() {
		return ((int)(javaScore + dbmsScore + htmlScore)/3);
	}

	
	
}
