package ex04_신동석;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		//student 객체 생성
		//입력클래스 import
		//반복문(while) 1부터 100까지 아니라는 조건(if)이라면, 다시 입력 문구 진행
		//	범위는 1부터 100까지 조건이 맞다면 입력값 변수에 저장
		// 
		//
		//	총점 출력 -> syso(st.getTotal())로 진행
		//  평균 출력 -> syso(st.getAverageScore())로 진행
		
	
		Scanner sc = new Scanner(System.in);
				
		System.out.print("avaScore, int dbmsScore, int htmlScore 순으로 입력 : ");
		
		
	}
}
