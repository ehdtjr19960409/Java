package ex05_신동석;

public class Main {

}
